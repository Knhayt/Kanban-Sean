import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {
  CdkDragDrop,
  CdkDropList,
  CdkDropListGroup,
  DragDropModule,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormsModule, NgModel } from '@angular/forms';
interface Task {
  name: string;
  dueDate: string; // Added due date field
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    DragDropModule,
    CdkDropList,
    CommonModule,
    CdkDropListGroup,
    FormsModule,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'Kanban-B';
  todoTaskName = '';
  constructor(private http: HttpClient) {}
  createToDoTask() {
    let data = {
      name: this.todoTaskName,
      status: 'todo',
    };
    this.http.post('/api/create_task', data).subscribe((result) => {
      console.log(result);
      this.todoTaskName = ''; // Clear the input field after task creation
    });
  }

  // Define task structure with name and due date
  todoTasks: Task[] = [
    { name: 'Task 1', dueDate: '2024-10-25' },
    { name: 'Task 2', dueDate: '2024-10-27' },
    { name: 'Task 3', dueDate: '2024-10-28' },
  ];

  inProgressTasks: Task[] = [
    { name: 'Task 4', dueDate: '2024-10-20' },
    { name: 'Task 5', dueDate: '2024-10-23' },
  ];

  doneTasks: Task[] = [
    { name: 'Task 6', dueDate: '2024-10-22' },
    { name: 'Task 7', dueDate: '2024-10-23' },
  ];

  // Handles drag-and-drop
  drop(event: CdkDragDrop<Task[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
  }
}
